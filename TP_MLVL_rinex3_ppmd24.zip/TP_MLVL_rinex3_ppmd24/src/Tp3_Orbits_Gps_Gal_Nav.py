# -*- coding: utf-8 -*-
"""
Created on %(date)s

@author: %(username)s
"""
import os
import numpy as np
import gpsdatetime as gpst

""" Import du module orbits """
# version locale
#import sys
#sys.path.append("/home/beilin/progs/Prog_scientifique/Packages/yagnss_toolbox/python/src/pygnsstoolbox/gnsstoolbox")
#import orbits

# version installee
import gnsstoolbox.orbits as orbits

def tp3_pos_sat_brdc(orb, const, prn, mjd):
    """ Calcul de la postion du satellite "const/prn"
    à un instant donné mjd """
    X_ECEF, Y_ECEF, Z_ECEF, dte = 0,0,0,0

    """ A COMPLETER (TP3) """
    Eph = orb.getEphemeris(const,prn,mjd)
    print("TOE : ", Eph.mjd)
    
    t = gpst.gpsdatetime(mjd=mjd)
    
    print("demi-grand axe a=%.3fm" % (Eph.sqrt_a**2))
    print(Eph.mjd, mjd)

    return X_ECEF, Y_ECEF, Z_ECEF, dte


if __name__ == "__main__":

    tic = gpst.gpsdatetime()

    Orb = orbits.orbit()

    """ lecture du fichier BRDC """
    dir_orb = '../data'
    Orb.loadRinexN(os.path.join(dir_orb, 'MLVL00FRA_R_20212400000_01D_GN.rnx'))

    """ Definition de l'instant pour lequel on cherche une position """
    t = gpst.gpsdatetime(yyyy=2021,doy=240,dsec=5435)
    print(t)

    """ SATELLITE """
    constellation = 'G'
    prn = 14

    try:
        Eph = Orb.getEphemeris(constellation,prn,t.mjd)
        print(Eph)
        print("TOC : ",Eph.tgps.st_iso_epoch())
             
    except:
        print("Unable to find satellite !!! ")

    print("\nCalcul avec la fonction integee a la toolbox")
    X,Y,Z,dte = Orb.calcSatCoord(constellation,prn,t.mjd) 
    print("Solution pygnssToolbox\nX = %13.3f m\nY = %13.3f m\nZ = %13.3f m\ndte = %.9f s" % (X,Y,Z,dte))
    
    """ impression des elements de debug """
#    print(Orb.debug.__dict__)

    print("\nCalcul avec la fonction developpee lors du TP")
    X,Y,Z,dte = tp3_pos_sat_brdc(Orb, constellation,prn,t.mjd)
    print("Solution TP\nX = %13.3f m\nY = %13.3f m\nZ = %13.3f m\ndte = %.9f s" % (X,Y,Z,dte))

    toc = gpst.gpsdatetime()
    print ('%.3f sec elapsed ' % (toc-tic))

